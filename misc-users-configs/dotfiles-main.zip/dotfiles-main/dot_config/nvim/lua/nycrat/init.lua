require("nycrat.options")
require("nycrat.commands")
require("nycrat.lazy")
require("nycrat.remaps")

vim.cmd([[colorscheme rose-pine]]) -- some issues with gitgutter color if in after
